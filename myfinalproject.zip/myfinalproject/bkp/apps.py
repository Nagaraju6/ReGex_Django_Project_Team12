from django.apps import AppConfig


class MyfinalappConfig(AppConfig):
    name = 'myfinalapp'
