from django.shortcuts import render
from django.http import HttpResponse
from .forms import forms

# Create your views here.
def index(request):
    if request.method == 'POST':
        member = WebMember(username=request.POST['username'], password=request.POST['password'],  firstname=request.POST['firstname'], lastname=request.POST['lastname'])
        member.save()
        return redirect('/')
    else:
        return render(request, 'index.html')

def login(request,uname):
	if uname=='admin':
		return render(request,'login.html')
	else:
		return render(request,'failedlogin.html')

def inputdata(request):
	return render(request,'inputdata.html')

def form(request):
	form=form(request.POST or none)
	if form.is_valid():
		print(form.cleaned_data)