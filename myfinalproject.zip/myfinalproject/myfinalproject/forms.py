from django import forms

class ColorfulContactForm(forms.Form):
    Project Name = forms.CharField(
        max_length=30,
        widget=forms.TextInput(
            attrs={
                'style': 'border-color: blue;',
                'placeholder': 'Your Project name here'
            }
        )
    )
    Your Name = forms.NameField(
        max_length=254,
        widget=forms.TextInput(attrs={'style': 'border-color: green;','placeholder': 'Your name here'})
    )
    message = forms.CharField(
        max_length=2000,
        widget=forms.Textarea(attrs={'style': 'border-color: orange;'}),
        help_text='Write here your message in detail!'
    )
    Percentage Completion = forms.CharField(
        max_length=2000,
        widget=forms.InputText(attrs={'style': 'border-color: orange;'}),
        help_text='How much work is completed'
    )